export const ACCEPT_DOMAINS = [
    'http://localhost:3000'
]